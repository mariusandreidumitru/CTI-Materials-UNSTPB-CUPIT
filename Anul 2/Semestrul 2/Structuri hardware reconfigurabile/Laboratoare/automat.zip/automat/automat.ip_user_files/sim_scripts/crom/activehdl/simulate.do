onbreak {quit -force}
onerror {quit -force}

asim +access +r +m+crom -L xil_defaultlib -L secureip -O5 xil_defaultlib.crom

do {wave.do}

view wave
view structure

do {crom.udo}

run -all

endsim

quit -force
