----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2025 02:01:38 PM
-- Design Name: 
-- Module Name: conexiune3 - conexiune3_a
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity conexiune3 is
    Port ( vcc : out STD_LOGIC;
           gnd : out STD_LOGIC);
end conexiune3;

architecture conexiune3_a of conexiune3 is

begin

    vcc <= '1';
    gnd <= '0';

end conexiune3_a;
