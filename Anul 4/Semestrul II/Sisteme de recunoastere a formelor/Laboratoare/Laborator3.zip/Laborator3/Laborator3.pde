import gab.opencv.*;
import processing.video.*;

Movie video;
OpenCV opencv;
int threshold=60;
boolean play=true;
int fr=25;
PImage[] cadre;
PImage cadruMediu;
int N=20;

void setup() {
  cadre=new PImage[N];
  size(720, 480);
  video = new Movie(this, "street.mov");
  opencv = new OpenCV(this, 720, 480);
  
  video.loop();
  video.frameRate(25);
  while (video.height == 0)  delay(2);
  opencv.loadImage(video);
  for(int i=0; i<N; i++)
    cadre[i]=opencv.getSnapshot();
  cadruMediu=opencv.getSnapshot();
}

void draw() {
  opencv.loadImage(video);
  
  for(int i=0; i<N-1; i++)
    cadre[i]=cadre[i+1];
    
  cadre[N-1]=opencv.getSnapshot();
  

  
  
  for(int x=0;x<cadre[0].width;x++) {
    for(int y=0;y<cadre[0].height;y++) {
       int loc=y*width+x;
       float r=0;
       float g=0;
       float b=0;
       for(int i=0;i<N;i++) {
          r+=red(cadre[i].pixels[loc]); 
          g+=green(cadre[i].pixels[loc]);
          b+=blue(cadre[i].pixels[loc]);
       }       
       cadruMediu.pixels[loc]=color(r/N,g/N,b/N);
       if(distanta(cadruMediu.pixels[loc], cadre[N-1].pixels[loc])>threshold)
         cadruMediu.pixels[loc]=color(255); else cadruMediu.pixels[loc]=color(0);
    }
  }
      
  cadruMediu.updatePixels();
  
  image(video, 0, 0);
  
  
  opencv.loadImage(cadruMediu);
  noFill();
  stroke(255, 0, 0);
  strokeWeight(3);
  for (Contour contour : opencv.findContours()) {
    int w=contour.getBoundingBox().width;
    int h=contour.getBoundingBox().height;
    if(w*h>20) {
      contour.draw();
    }
    
  }
  
}

void movieEvent(Movie m) {
    m.read();
}

float distanta(color c1, color c2){
 float d=sqrt((red(c1)-red(c2))*(red(c1)-red(c2))+(blue(c1)-blue(c2))*(blue(c1)-blue(c2))+(green(c1)-green(c2))*(green(c1)-green(c2)));
 return d;
}
