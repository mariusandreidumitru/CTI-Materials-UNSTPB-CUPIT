PImage img;
int c=255;
int raza=20;
/**
 * Histogram. 
 * 
 * Calculates the histogram of an image. 
 * A histogram is the frequency distribution 
 * of the gray levels with the number of pure black values
 * displayed on the left and number of pure white values on the right. 
 *
 * Note that this sketch will behave differently on Android, 
 * since most images will no longer be full 24-bit color.
 */
void settings(){
  img = loadImage("frontier.jpg");
  size(img.width,img.height);
}



void setup(){
// Load an image from the data directory
// Load a different image by modifying the comments

}

void draw(){

image(img, 0, 0);
int[] hist = new int[256];

// Calculate the histogram
for (int i = 0; i < img.width; i++) {
  for (int j = 0; j < img.height; j++) {
    int bright = int(brightness(get(i, j)));
    hist[bright]++; 
  }
}

// Find the largest value in the histogram
int histMax = max(hist);

stroke(255);
// Draw half of the histogram (skip every second value)
  for (int i = 0; i < img.width; i += 2) {
  // Map i (from 0..img.width) to a location in the histogram (0..255)
  int which = int(map(i, 0, img.width, 0, 255));
  // Convert the histogram value to a location between 
  // the bottom and the top of the picture
  int y = int(map(hist[which], 0, histMax, img.height, 0));
  line(i, img.height, i, y);
  }

fill(c,c,c,100);
circle(mouseX,mouseY,raza*2);

if(mousePressed)
  for (int i = 0; i < img.width; i++) {
    for (int j = 0; j < img.height; j++) {
      color culoare = get(i, j);
      float r=red(culoare);
      float g=green(culoare);
      float b=blue(culoare);
      int x;
      if(c==255) x=1; else x=-1;
      if((i-mouseX)*(i-mouseX)+(j-mouseY)*(j-mouseY)<raza*raza) img.set(i,j,color(r+x,g+x,b+x));
  }
}
delay(10);
}

void keyPressed(){
   if(key=='c') {
     if(c==255) c=0; else c=255;
   }
  
}
