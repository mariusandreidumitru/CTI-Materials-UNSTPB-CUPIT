-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue Apr 29 16:18:35 2025
-- Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/SHRCN2025/automat/automat.gen/sources_1/bd/crom/ip/crom_conexiune1_0_0/crom_conexiune1_0_0_sim_netlist.vhdl
-- Design      : crom_conexiune1_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7s100fgga676-2
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity crom_conexiune1_0_0 is
  port (
    data : in STD_LOGIC_VECTOR ( 7 downto 0 );
    selDmux : out STD_LOGIC_VECTOR ( 1 downto 0 );
    selMux : out STD_LOGIC_VECTOR ( 1 downto 0 );
    cin : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of crom_conexiune1_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of crom_conexiune1_0_0 : entity is "crom_conexiune1_0_0,conexiune1,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of crom_conexiune1_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of crom_conexiune1_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of crom_conexiune1_0_0 : entity is "conexiune1,Vivado 2020.2";
end crom_conexiune1_0_0;

architecture STRUCTURE of crom_conexiune1_0_0 is
  signal \^data\ : STD_LOGIC_VECTOR ( 7 downto 0 );
begin
  \^data\(7 downto 0) <= data(7 downto 0);
  cin(3 downto 0) <= \^data\(3 downto 0);
  selDmux(1 downto 0) <= \^data\(5 downto 4);
  selMux(1 downto 0) <= \^data\(7 downto 6);
end STRUCTURE;
