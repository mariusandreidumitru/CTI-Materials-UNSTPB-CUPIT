--Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
--Date        : Tue Apr 29 18:24:05 2025
--Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
--Command     : generate_target crom.bd
--Design      : crom
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity crom is
  port (
    F : out STD_LOGIC_VECTOR ( 3 downto 0 );
    T1 : in STD_LOGIC;
    T2 : in STD_LOGIC;
    adrese : out STD_LOGIC_VECTOR ( 7 downto 0 );
    clk : in STD_LOGIC;
    data : out STD_LOGIC_VECTOR ( 7 downto 0 );
    reset : in STD_LOGIC
  );
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of crom : entity is "crom,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=crom,x_ipVersion=1.00.a,x_ipLanguage=VHDL,numBlks=7,numReposBlks=7,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=7,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}";
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of crom : entity is "crom.hwdef";
end crom;

architecture STRUCTURE of crom is
  component crom_numarator_0_0 is
  port (
    reset : in STD_LOGIC;
    clk : in STD_LOGIC;
    load : in STD_LOGIC;
    cin : in STD_LOGIC_VECTOR ( 3 downto 0 );
    q : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  end component crom_numarator_0_0;
  component crom_dmux1_4_0_0 is
  port (
    e : in STD_LOGIC;
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    y : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  end component crom_dmux1_4_0_0;
  component crom_mux4_1_0_0 is
  port (
    i0 : in STD_LOGIC;
    i1 : in STD_LOGIC;
    i2 : in STD_LOGIC;
    i3 : in STD_LOGIC;
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    y : out STD_LOGIC
  );
  end component crom_mux4_1_0_0;
  component crom_conexiune1_0_0 is
  port (
    data : in STD_LOGIC_VECTOR ( 7 downto 0 );
    selDmux : out STD_LOGIC_VECTOR ( 1 downto 0 );
    selMux : out STD_LOGIC_VECTOR ( 1 downto 0 );
    cin : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  end component crom_conexiune1_0_0;
  component crom_conexiune2_0_0 is
  port (
    q : in STD_LOGIC_VECTOR ( 3 downto 0 );
    adrese : out STD_LOGIC_VECTOR ( 7 downto 0 );
    cs : out STD_LOGIC;
    oe : out STD_LOGIC
  );
  end component crom_conexiune2_0_0;
  component crom_conexiune3_0_0 is
  port (
    vcc : out STD_LOGIC;
    gnd : out STD_LOGIC
  );
  end component crom_conexiune3_0_0;
  component crom_rom256x8_0_0 is
  port (
    adrese : in STD_LOGIC_VECTOR ( 7 downto 0 );
    cs : in STD_LOGIC;
    oe : in STD_LOGIC;
    clk : in STD_LOGIC;
    data : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  end component crom_rom256x8_0_0;
  signal T1_1 : STD_LOGIC;
  signal T2_1 : STD_LOGIC;
  signal clk_1 : STD_LOGIC;
  signal conexiune1_0_cin : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal conexiune1_0_selDmux : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal conexiune1_0_selMux : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal conexiune2_0_adrese : STD_LOGIC_VECTOR ( 7 downto 0 );
  attribute DEBUG : string;
  attribute DEBUG of conexiune2_0_adrese : signal is "true";
  attribute MARK_DEBUG : boolean;
  attribute MARK_DEBUG of conexiune2_0_adrese : signal is std.standard.true;
  signal conexiune2_0_cs : STD_LOGIC;
  signal conexiune2_0_oe : STD_LOGIC;
  signal conexiune3_0_gnd : STD_LOGIC;
  signal conexiune3_0_vcc : STD_LOGIC;
  signal dmux1_4_0_y : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal mux4_1_0_y : STD_LOGIC;
  signal numarator_0_q : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal reset_1 : STD_LOGIC;
  signal rom256x8_0_data : STD_LOGIC_VECTOR ( 7 downto 0 );
begin
  F(3 downto 0) <= dmux1_4_0_y(3 downto 0);
  T1_1 <= T1;
  T2_1 <= T2;
  adrese(7 downto 0) <= conexiune2_0_adrese(7 downto 0);
  clk_1 <= clk;
  data(7 downto 0) <= rom256x8_0_data(7 downto 0);
  reset_1 <= reset;
conexiune1_0: component crom_conexiune1_0_0
     port map (
      cin(3 downto 0) => conexiune1_0_cin(3 downto 0),
      data(7 downto 0) => rom256x8_0_data(7 downto 0),
      selDmux(1 downto 0) => conexiune1_0_selDmux(1 downto 0),
      selMux(1 downto 0) => conexiune1_0_selMux(1 downto 0)
    );
conexiune2_0: component crom_conexiune2_0_0
     port map (
      adrese(7 downto 0) => conexiune2_0_adrese(7 downto 0),
      cs => conexiune2_0_cs,
      oe => conexiune2_0_oe,
      q(3 downto 0) => numarator_0_q(3 downto 0)
    );
conexiune3_0: component crom_conexiune3_0_0
     port map (
      gnd => conexiune3_0_gnd,
      vcc => conexiune3_0_vcc
    );
dmux1_4_0: component crom_dmux1_4_0_0
     port map (
      e => conexiune3_0_vcc,
      s(1 downto 0) => conexiune1_0_selDmux(1 downto 0),
      y(3 downto 0) => dmux1_4_0_y(3 downto 0)
    );
mux4_1_0: component crom_mux4_1_0_0
     port map (
      i0 => conexiune3_0_vcc,
      i1 => T1_1,
      i2 => T2_1,
      i3 => conexiune3_0_gnd,
      s(1 downto 0) => conexiune1_0_selMux(1 downto 0),
      y => mux4_1_0_y
    );
numarator_0: component crom_numarator_0_0
     port map (
      cin(3 downto 0) => conexiune1_0_cin(3 downto 0),
      clk => clk_1,
      load => mux4_1_0_y,
      q(3 downto 0) => numarator_0_q(3 downto 0),
      reset => reset_1
    );
rom256x8_0: component crom_rom256x8_0_0
     port map (
      adrese(7 downto 0) => conexiune2_0_adrese(7 downto 0),
      clk => clk_1,
      cs => conexiune2_0_cs,
      data(7 downto 0) => rom256x8_0_data(7 downto 0),
      oe => conexiune2_0_oe
    );
end STRUCTURE;
