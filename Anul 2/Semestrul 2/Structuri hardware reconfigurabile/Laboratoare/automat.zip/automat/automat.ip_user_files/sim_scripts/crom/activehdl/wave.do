add wave *
