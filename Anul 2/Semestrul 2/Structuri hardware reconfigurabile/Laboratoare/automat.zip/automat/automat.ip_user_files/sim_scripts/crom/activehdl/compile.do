vlib work
vlib activehdl

vlib activehdl/xil_defaultlib

vmap xil_defaultlib activehdl/xil_defaultlib

vcom -work xil_defaultlib -93 \
"../../../bd/crom/ip/crom_rom256x8_0_0/sim/crom_rom256x8_0_0.vhd" \
"../../../bd/crom/ip/crom_numarator_0_0/sim/crom_numarator_0_0.vhd" \
"../../../bd/crom/ip/crom_dmux1_4_0_0/sim/crom_dmux1_4_0_0.vhd" \
"../../../bd/crom/ip/crom_mux4_1_0_0/sim/crom_mux4_1_0_0.vhd" \
"../../../bd/crom/ip/crom_conexiune1_0_0/sim/crom_conexiune1_0_0.vhd" \
"../../../bd/crom/ip/crom_conexiune2_0_0/sim/crom_conexiune2_0_0.vhd" \
"../../../bd/crom/ip/crom_conexiune3_0_0/sim/crom_conexiune3_0_0.vhd" \
"../../../bd/crom/sim/crom.vhd" \


