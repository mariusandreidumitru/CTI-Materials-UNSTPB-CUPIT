// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain
// Code for: https://youtu.be/1scFcY-xMrI

class Blob {
  int minx;
  int miny;
  int maxx;
  int maxy;

  ArrayList<PVector> points;

  Blob(int x, int y) {
    minx = x;
    miny = y;
    maxx = x;
    maxy = y;
    points = new ArrayList<PVector>();
    points.add(new PVector(x, y));
  }

  void show() {
    stroke(50);
    noFill();
    strokeWeight(2);
    rectMode(CORNERS);
    rect(minx, miny+yt, maxx, maxy+yt);
  }
  
  void highlight() {
    stroke(250,0,100);
    noFill();
    strokeWeight(2);
    rectMode(CORNERS);
    rect(minx, miny+yt, maxx, maxy+yt);
  }



  void add(int x, int y) {
    points.add(new PVector(x, y));
    minx = min(minx, x);
    miny = min(miny, y);
    maxx = max(maxx, x);
    maxy = max(maxy, y);
  }

  float size() {
    return (maxx-minx)*(maxy-miny);
  }

  boolean isNear(float x, float y) {

    // Closest point in blob strategy
    float d = 10000000;
    for (PVector v : points) {
      float tempD = distanta(x, y, v.x, v.y);
      if (tempD < d) {
        d = tempD;
      }
    }

    if (d < 7) {
      return true;
    } else {
      return false;
    }
  }
}
