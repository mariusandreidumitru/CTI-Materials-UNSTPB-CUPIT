----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2025 01:04:49 PM
-- Design Name: 
-- Module Name: numarator - numarator_a
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity numarator is
    Port ( reset : in STD_LOGIC;
           clk : in STD_LOGIC;
           load : in STD_LOGIC;
           cin : in STD_LOGIC_VECTOR (3 downto 0);
           q : out STD_LOGIC_VECTOR (3 downto 0));
end numarator;

architecture numarator_a of numarator is

begin
process(reset,clk)
variable vq : std_logic_vector(3 downto 0);
begin
    if reset = '1' then
        vq := "0000";
    else
        if clk'event and clk='1' then
            if load = '0' then 
                vq := cin;
            else
                vq := vq + '1';
            end if;
        end if;
   end if;
   q <= vq;
end process;
            

end numarator_a;
