import processing.video.*;

Capture v;

color culoareReferinta=color(255,0,0);
float pragCuloare=10;
float pragDistanta=30;

ArrayList<Blob> blobs=new ArrayList<Blob>();

void settings(){
  size(640,360);
}

void setup(){
 String[] cameras=Capture.list();
 printArray(cameras);
 v=new Capture(this, 640,360, cameras[0]);
 v.start(); 
}
    
void captureEvent(Capture vid){
 vid.read();  
}

void draw(){
 blobs.clear();
 image(v,0,0);
 float r1=red(culoareReferinta);
 float g1=green(culoareReferinta);
 float b1=blue(culoareReferinta);
 for(int i=0;i<v.width;i++){
   for(int j=0;j<v.height;j++){
     color culoarePixel=v.get(i,j);
     float r2=red(culoarePixel);
     float g2=green(culoarePixel);
     float b2=blue(culoarePixel);
     float distCuloare=sqrt((r2-r1)*(r2-r1)+(g2-g1)*(g2-g1)+(b2-b1)*(b2-b1));    
     if(distCuloare<pragCuloare){
       boolean gasit=false;
       for(Blob obiect:blobs){
         if(obiect.isNear(i,j)){
           obiect.add(i,j);
           gasit=true;
           break;
         }
       }
       if(!gasit){
         Blob obiect=new Blob(i,j);
         blobs.add(obiect);
       }       
     }
   }
 }
 
   for(Blob obiect:blobs){
        if(obiect.size()>200) obiect.show(); 
   }  
}


void mousePressed(){
  culoareReferinta=v.get(mouseX,mouseY); 
  
}
