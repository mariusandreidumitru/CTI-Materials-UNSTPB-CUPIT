import gab.opencv.*;

PImage img1,img2;
int w,h;
int[] hist1=new int[256];
int[] hist2=new int[256];
int[] histSum=new int[256];
float factor=0.7; // factor de egalizare
float nrMax=0.01; // numar maxim de pixeli pe nivel

OpenCV opencv;
PImage canny1,canny2;


void settings(){
 img1=loadImage("laborator1.jpg"); 
 w=img1.width;
 h=img1.height;
 w=w/2;
 h=h/2;
 img1.resize(w,h);
 size(3*w,2*h);

}

void setup(){
 image(img1,0,0); 
 for(int i=0;i<w;i++){
   for(int j=0;j<h;j++){
      int bright=int(brightness(img1.get(i,j)));
      hist1[bright]++;
   }
 }
 
 stroke(255);
 int histMax=max(hist1);
 for(int i=0;i<=255;i++){
   print(hist1[i]+",");  
   int x=int(map(i,0,255,0,w));
   int y=int(map(hist1[i],0,histMax,0,h-10));
   if(hist1[i]>nrMax*w*h) hist1[i]=int(nrMax*w*h);
   if(i>0) histSum[i]=histSum[i-1]+hist1[i];
     else histSum[i]=hist1[0];
    line(w+x,h,w+x,h-y);   
 }
 
 img2=img1.copy();
   
 for(int i=0;i<w;i++){
   for(int j=0;j<h;j++){
      color c1=img1.get(i,j);
      int bright=int(brightness(c1));
      float r=red(c1);
      float g=green(c1);
      float b=blue(c1);
      r=r/bright*255*(1-factor)/2+255*factor*histSum[bright]/histSum[255];
      g=g/bright*255*(1-factor)/2+255*factor*histSum[bright]/histSum[255];
      b=b/bright*255*(1-factor)/2+255*factor*histSum[bright]/histSum[255];
      color c2=color(r,g,b);
      img2.set(i,j,c2);
      bright=int(brightness(img2.get(i,j)));
      hist2[bright]++;
     
   }
 }
 
 for(int i=0;i<=255;i++){     
   int x=int(map(i,0,255,0,w));
   int y=int(map(hist2[i],0,histMax,0,h-10));
   line(w+x,2*h,w+x,2*h-y);   
 }
    
 image(img2, 0, h);
 
 int pragMin=140;
 int pragMax=170;
 
 opencv=new OpenCV(this,img1);
 opencv.findCannyEdges(pragMin,pragMax);
 canny1=opencv.getSnapshot();
 
 opencv=new OpenCV(this,img2);
 opencv.findCannyEdges(pragMin,pragMax);
 canny2=opencv.getSnapshot();
 
 image(canny1,2*w,0);
 image(canny2,2*w,h);
}
