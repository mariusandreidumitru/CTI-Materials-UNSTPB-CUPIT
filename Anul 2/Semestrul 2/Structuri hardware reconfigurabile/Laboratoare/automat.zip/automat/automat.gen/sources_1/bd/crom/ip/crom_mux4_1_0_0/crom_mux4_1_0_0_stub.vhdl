-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue Apr 29 16:18:34 2025
-- Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               d:/SHRCN2025/automat/automat.gen/sources_1/bd/crom/ip/crom_mux4_1_0_0/crom_mux4_1_0_0_stub.vhdl
-- Design      : crom_mux4_1_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7s100fgga676-2
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity crom_mux4_1_0_0 is
  Port ( 
    i0 : in STD_LOGIC;
    i1 : in STD_LOGIC;
    i2 : in STD_LOGIC;
    i3 : in STD_LOGIC;
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    y : out STD_LOGIC
  );

end crom_mux4_1_0_0;

architecture stub of crom_mux4_1_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "i0,i1,i2,i3,s[1:0],y";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "mux4_1,Vivado 2020.2";
begin
end;
