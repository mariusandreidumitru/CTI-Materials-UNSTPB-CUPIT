----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2025 01:49:31 PM
-- Design Name: 
-- Module Name: conexiune1 - conexiune1_a
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity conexiune1 is
    Port ( data : in STD_LOGIC_VECTOR (7 downto 0);
           selDmux : out STD_LOGIC_VECTOR (1 downto 0);
           selMux : out STD_LOGIC_VECTOR (1 downto 0);
           cin : out STD_LOGIC_VECTOR (3 downto 0));
end conexiune1;

architecture conexiune1_a of conexiune1 is

begin
selDmux <= data(5 downto 4);
selMux <= data(7 downto 6);
cin <= data(3 downto 0);

end conexiune1_a;
