PImage source;       // Source image
PImage destination;  // Destination image
float threshold = 150;
PFont f; 
int minpix=10;
int fheight=13;
int fwidth=13;
String numePoza="antrenare.jpg";
PrintWriter output;
boolean scris=false;

int[][] a = new int[1000][1000];
String[] structuri= new String[140000];
String[] structuri_reduse= new String[3000];
int[] pixeli=new int[140000];
int nr=0;
int nr_reduse=0;
int[] deverificat=new int[140000];
int poz=0;
int nr_structura=0;
boolean calculat=false;
int latime, inaltime;
int[] ylinie=new int[200];
int nr_linii=0;
int directie=0;

void settings(){
  PImage img = loadImage(numePoza);  
  size(img.width,img.height);
}

void setup() {

  source = loadImage(numePoza);  
  // The destination image is created as a blank image the same size as the source.
  latime=source.width;
  inaltime=source.height;
  destination = createImage(latime, inaltime, RGB);
  f = createFont("Arial",16,true);
  black_white(); 
  realizeaza_structuri();
}

void draw() {  
  black_white();  
  textFont(f,16);
  fill(0);  
  text(threshold,50,50);
}

void keyPressed(){
  if(key == 'a') {threshold++; calculat=false; nr_structura=0; realizeaza_structuri();}
  if(key == 's') {threshold--; calculat=false; nr_structura=0; realizeaza_structuri();}
  if(key == 'm') nr_structura=nr_structura+1;
  if(key == 'n') nr_structura=nr_structura-1;
  if(key == 'd' && scris==false) {
     output = createWriter("litere.txt"); 
     for(nr_structura=0; nr_structura<nr_reduse; nr_structura++) {
        detecteaza(); 
     }
     output.flush();
     output.close();
  }
  
  if(nr_structura==-1) nr_structura=nr_reduse-1;
  if(nr_structura==nr_reduse) nr_structura=0;
}


void detecteaza(){
  int[] structura_curenta=new int[200];
  int[] x=new int[200];
  int[] y=new int[200];
  int[][] M=new int[fheight][fwidth];
  int maxx=0,maxy=0,minx=10000,miny=10000;
  structura_curenta=int(split(structuri_reduse[nr_structura], ','));
  for(int i=0;i<structura_curenta.length;i++){
   x[i]=structura_curenta[i]%latime;
   y[i]=structura_curenta[i]/latime;
   if(x[i]>maxx) maxx=x[i];
   if(y[i]>maxy) maxy=y[i];
   if(x[i]<minx) minx=x[i];
   if(y[i]<miny) miny=y[i];   
  }
  int maxM=0;
  for(int i=0;i<structura_curenta.length;i++){
   M[int(floor((y[i]-miny)*fheight/(maxy-miny+1)))][int(floor((x[i]-minx)*fwidth/(maxx-minx+1)))]++;
   if(M[int(floor((y[i]-miny)*fheight/(maxy-miny+1)))][int(floor((x[i]-minx)*fwidth/(maxx-minx+1)))]>maxM) maxM=M[int(floor((y[i]-miny)*fheight/(maxy-miny+1)))][int(floor((x[i]-minx)*fwidth/(maxx-minx+1)))];
  }
  String litera="";
  for(int j=0; j<fheight; j++) {
    for(int i=0; i<fwidth; i++)
    {
       if(M[j][i]>maxM*0.3) litera=litera+",1"; else litera=litera+",-1"; 
    }
  }
  litera=litera.substring(1);
  output.println(litera);
  scris=true;
}
  


void black_white()
{
    // We are going to look at both image's pixels
  source.loadPixels();
  destination.loadPixels();
    
  for (int x = 0; x < latime; x++) {
    for (int y = 0; y < inaltime; y++ ) {
      int loc = x + y*latime;
      // Test the brightness against the threshold
      if (brightness(source.pixels[loc]) > threshold) {
        destination.pixels[loc]  = color(255);  // White
        a[y][x]=0;
      }  else {
        destination.pixels[loc]  = color(0);    // Black
        if(y==0 || x==0 || y==inaltime-1 || x==latime-1) a[y][x]=0; else a[y][x]=1;
      }
    }
  }

  if(calculat){
    int[] structura_curenta=new int[100];
    structura_curenta=int(split(structuri_reduse[nr_structura], ','));   
    for(int i=0;i<structura_curenta.length;i++){
          destination.pixels[structura_curenta[i]]  = color(255,0, 255);
    }
  }
  // We changed the pixels in destination
  destination.updatePixels();
  // Display the destination
  image(destination,0,0);
}

void realizeaza_structuri(){ 
  for (int i = 0; i < inaltime; i++) {
      for (int j = 0; j < latime; j++ ) {
         if(a[i][j]==1) {
             boolean sem=false;
             int locatie_curenta=i*latime+j;
             for(int k=0; k<nr; k++) {
                pixeli=int(split(structuri[k], ','));
                for(int l=0; l<pixeli.length; l++){
                  if(locatie_curenta==pixeli[l]) {sem=true; break;} 
                }
             }
         
             if(sem==false){
                 nr++;
                 structuri[nr-1]=str(locatie_curenta);
                 deverificat[poz]=locatie_curenta;
                 poz++;
             }
                 
             while(poz>0){
                 poz--;
                 locatie_curenta=deverificat[poz];
                 int indexi=locatie_curenta/latime;
                 int indexj=locatie_curenta%latime;
                 
                 for(int ix=-1; ix<2; ix++){
                    for(int jx=-1; jx<2; jx++){
                      if(ix!=0 || jx!=0)
                        if(a[indexi+ix][indexj+jx]==1) {
                          locatie_curenta=(indexi+ix)*latime+(indexj+jx);
                          int[] structura_curenta=int(split(structuri[nr-1], ','));
                          boolean sem_dubluri=true;
                          for(int m=0; m<structura_curenta.length; m++)
                                  if(locatie_curenta==structura_curenta[m]) {sem_dubluri=false; break;}
                          if(sem_dubluri){
                            structuri[nr-1]=structuri[nr-1]+","+str(locatie_curenta);
                            deverificat[poz]=locatie_curenta;
                            poz++;
                          }
                       }
                     }
                 }
             
             }
        }
      }
   }
   calculat=true;
   ordonare_structuri();
}


void ordonare_structuri(){
   int[] pozitie=new int[140000];
   int[] pozitie_ordonate=new int[140000];
   int pozitie_maxima=0;
   int pozitie_minima=10000000;
   String[] structuri_ordonate= new String[140000];
   for(int j=0; j<nr; j++){
         int[] structura_curenta=new int[200];
         int[] x=new int[200];
         int[] y=new int[200];
         int[][] M=new int[fheight][fwidth];
         int maxx=0,maxy=0,minx=10000,miny=10000;
         structura_curenta=int(split(structuri[j], ','));
         for(int i=0;i<structura_curenta.length;i++){
           x[i]=structura_curenta[i]%latime;
           y[i]=structura_curenta[i]/latime;
           if(x[i]>maxx) maxx=x[i];
           if(y[i]>maxy) maxy=y[i];
           if(x[i]<minx) minx=x[i];
           if(y[i]<miny) miny=y[i];         
        }
        boolean sem=false;
        for(int i=0;i<nr_linii;i++){
           if(ylinie[i]<maxy && ylinie[i]>miny){
             sem=true;
             pozitie[j]=ylinie[i]*latime+minx;
           }
        }
        if(!sem){
           ylinie[nr_linii]=int((maxy+miny)/2);
           pozitie[j]=ylinie[nr_linii]*latime+minx;
           nr_linii++;
        }
        if(pozitie_maxima<pozitie[j]) {pozitie_maxima=pozitie[j]; structuri_ordonate[nr-1]=structuri[j]; pozitie_ordonate[nr-1]=pozitie_maxima; }
        if(pozitie_minima>pozitie[j]) {pozitie_minima=pozitie[j]; structuri_ordonate[0]=structuri[j]; pozitie_ordonate[0]=pozitie_minima;}
   }
   for(int j=1; j<nr-1;j++){
     int pozitie_curenta=pozitie_maxima;
     int actual=0;
     for(int i=0; i<nr; i++){
          if(pozitie[i]<pozitie_curenta && pozitie[i]>pozitie_ordonate[j-1]) { pozitie_curenta=pozitie[i]; actual=i; }          
     }
     pozitie_ordonate[j]=pozitie[actual];
     structuri_ordonate[j]=structuri[actual];
   }
   
   for(int j=0; j<nr;j++){
     int[] structura_curenta=new int[200];
     structura_curenta=int(split(structuri_ordonate[j], ','));
     int nrpix=structura_curenta.length;
     structuri_reduse[nr_reduse]=structuri_ordonate[j];
     if(nrpix>minpix) nr_reduse++; 
   }
   
}
