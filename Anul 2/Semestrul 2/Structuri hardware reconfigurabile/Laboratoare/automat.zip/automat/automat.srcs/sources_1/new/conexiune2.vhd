----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2025 01:55:26 PM
-- Design Name: 
-- Module Name: conexiune2 - conexiune2_a
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity conexiune2 is
    Port ( q : in STD_LOGIC_VECTOR (3 downto 0);
           adrese : out STD_LOGIC_VECTOR (7 downto 0);
           cs : out STD_LOGIC;
           oe : out STD_LOGIC);
end conexiune2;

architecture conexiune2_a of conexiune2 is

begin
adrese <= "0000" & q;
cs <= '1';
oe <= '1';

end conexiune2_a;
