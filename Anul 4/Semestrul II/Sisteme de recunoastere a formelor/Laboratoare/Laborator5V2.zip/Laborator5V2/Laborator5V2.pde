import gab.opencv.*;

OpenCV opencv;
ArrayList<Line> lines;
PImage src,src1,img1,img2;
int xt=3,yt=15;
boolean ready=false, afisaj=false;
ArrayList<Blob> blobs = new ArrayList<Blob>();
color bgColor=color(255);
int threshold=20;
char[] forme = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V'};
float[] minv1 = { 39.6,36.55,70.6,51.35,45.78,43.03,52,45.24,63,81.6,42.57,59.45,39.5,39.15,52.86,40.72,51.95,40.47,51.19,59.27,56.89,49.57 }; 
float[] minv2 = { 7.15,11.18,26.47,6.19,23.5,25.73,9.42,4.8,61,77.7,11.65,43.83,7.41,5.78,3,16.24,9.08,9.84,25.24,33.8,4.08,8.94 };
float[] minv3 = { 20.2,2.16,25.75,8.15,5.03,13.27,7.5,0.04,0.21,16.59,8.12,30.28,0.19,0.16,0.23,15.18,5.89,6.21,3.63,42.75,9.88,26.48 };
float[] minv4 = { 26,10.35,151.87,4.55,46.11,50,31.94,9.34,0.73,67.31,61.62,101.38,11.24,1.36,4.44,41.11,12.4,35.54,12.07,135.38,69,80.78 };
float stdev1,stdev2,stdev3,stdev4;

void settings(){
    src = loadImage("imaginez.jpg");
    src.resize(0, 250);
    size(src.width*3,src.height*2+30);
    src1=src.copy();
}

void setup() {

  curata();
  stdev1=stdev(minv1);
  stdev2=stdev(minv2);
  stdev3=stdev(minv3);
  stdev4=stdev(minv4);
}

void curata(){
  
  PImage alb=new PImage(src.width*3,src.height*2+30);
  for(int i=0; i<alb.width; i++){
     for(int j=0; j<alb.height; j++){
        alb.pixels[j*alb.width+i]=color(255); 
     }    
  }
  
  image(alb,0,0);
  
  img1=src1.copy();
  img1.filter(GRAY);
  img1.filter(INVERT);
  img1.filter(THRESHOLD, 0.3);
  opencv = new OpenCV(this, img1);
  opencv.findCannyEdges(20, 60);
  img2=opencv.getOutput();



  fill(250,50,50);
  textSize(10);

  
  image(src,0,yt);
  text("Originala",xt,10);
  
  PImage img1a=img1.copy();
  double m00=m(img1,0,0);
  double xc=m(img1,1,0)/m00;
  double yc=m(img1,0,1)/m00;
  
  img1a.resize(0,src.height);
  image(img1a,src.width+(src.width-img1a.width)/2,yt);
  text("Masca",src.width+xt,10);
  text("m(0,0) : "+m00,src.width+xt,yt+10);
  text("xc : "+xc,src.width+xt,yt+20);
  text("yc : "+yc,src.width+xt,yt+30);
  //circle(src.width+(src.width-img1a.width)/2+round(xc),yt+round(yc),5);
    m00=m(img1a,0,0);
    xc=m(img1a,1,0)/m00;
    yc=m(img1a,0,1)/m00;
    println("xc: ", xc);
    println("yc: ", yc);
    fill(255,0,0);
    circle(src.width+(src.width-img1a.width)/2+(float)xc,yt+(float)yc,5);
  
  
  float minv1n=(float)mi1(img1);
  float minv2n=(float)mi2(img1);
  float minv3n=(float)mi3(img1);
  float minv4n=(float)mi4(img1);
  
  
  text("inv1 : "+afisaj(minv1n),src.width+xt,yt+50);
  text("inv2 : "+afisaj(minv2n),src.width+xt,yt+60);
  text("inv3 : "+afisaj(minv3n),src.width+xt,yt+70);
  text("inv4 : "+afisaj(minv4n),src.width+xt,yt+80);
  
  int N=forme.length;
  float minimul=1000,minimulp=1000;
  int pozitia=0, pozitiap=0;
  for(int i=0; i<N; i++){
      float distanta=dist4(minv1[i],minv2[i],minv3[i],minv4[i],minv1n,minv2n,minv3n,minv4n,stdev1,stdev2,stdev3,stdev4);
      if(distanta<minimul) {
        minimulp=minimul;
        pozitiap=pozitia;
        minimul=distanta;
        pozitia=i; 
      }
      //println("dist("+forme[i]+"-?) = "+distanta);
  }
  println("Cel mai probabil este litera: "+forme[pozitia]);
  println("Daca nu, probabil este: "+forme[pozitiap]);  
  
  PImage src1a;
  // DFT(imagine, luminozitate)
  if(!afisaj) src1a=src.copy();
  else src1a=src1.copy();
//  image(DFT2(src1,10), 0, yt+src.height);
    
    src1a.resize(0,src.height);
    image(src1a,(src.width-src1a.width)/2,yt+src.height);

  
  text("Segmentare", xt, yt+2*src.height+10);
  
  if(afisaj) {
    //PImage imagine=DFT2(img2,10);
    //imagine.resize(0, src.height);
    //image(imagine, src.width+(src.width-imagine.width)/2, yt+src.height);
    text("Fourier(Canny)", src.width+xt, yt+2*src.height+10);
  }
  
  if(true){
    PImage img2a=img2.copy();
    img2a.resize(0,src.height);
    image(img2a,2*src.width+(src.width-img2a.width)/2,yt);
    text("Canny", 2*src.width+xt,10);
  }
  
  if(true){
    PImage img2a=Hough(img2);
    img2a.resize(0,src.height);
    image(img2a, 2*src.width+(src.width-img2a.width)/2, yt+src.height);
    text("Hough(Canny)", 2*src.width+xt,yt+2*src.height+10);
  }
  
  
   
  strokeWeight(1);
  stroke(0, 0, 255,150);
  //line(2*src.width,yt+1.5*src.height,3*src.width,yt+1.5*src.height);
  //line(2.5*src.width,yt+1*src.height,2.5*src.width,yt+2*src.height); 
  circle(2.5*src.width,yt+1.5*src.height,2);  
  ready=true;
  
  if(!afisaj) {
   // Begin loop to walk through every pixel
  for (int x = 0; x < src.width; x++ ) {
    for (int y = 0; y < src.height; y++ ) {
              int loc = x + y * src.width;
              // What is current color
              color currentColor = src.pixels[loc];
              
              float r1 = red(currentColor);
              float g1 = green(currentColor);
              float b1 = blue(currentColor);
              float r2 = red(bgColor);
              float g2 = green(bgColor);
              float b2 = blue(bgColor);
        
              float d = distanta(r1, g1, b1, r2, g2, b2); 
        
              if (d > threshold) {
        
                boolean found = false;
                for (Blob b : blobs) {
                  if (b.isNear(x, y)) {
                    b.add(x, y);
                    found = true;
                    break;
                  }
                }
        
                if (!found) {
                  Blob b = new Blob(x, y);
                  blobs.add(b);
                }
              }
            }
   }
   for (int j = blobs.size() - 1; j >= 0; j--) {
      Blob b1 = blobs.get(j);
      for (int i = blobs.size() - 1; i > j; i--) {
        Blob b2 = blobs.get(i);
        if (b1.minx-2<=b2.minx && b1.maxx+2>=b2.maxx && b1.miny-2<=b2.miny && b1.maxy+2>=b2.maxy){
            blobs.remove(i);
        }
       }      
   }
  }
   if(afisaj){
     for (Blob b : blobs) {            
              b.show(); 
              if(b.minx<mouseX && b.maxx>mouseX && b.miny<mouseY-yt && b.maxy>mouseY-yt){
                b.highlight();
              }
     }
   }
   
   
  
  strokeWeight(3);
  stroke(255, 0, 0);
  line(0,0,3*src.width,0);  
  line(0,yt+src.height,3*src.width,yt+src.height);
  line(0,2*(yt+src.height),3*src.width,2*(yt+src.height));
  line(src.width,0,src.width,2*src.height+2*yt);
  line(0,0,0,2*src.height+2*yt);
  line(2*src.width,0,2*src.width,2*src.height+2*yt);  
  line(3*src.width,0,3*src.width,2*src.height+2*yt); 
  
  
}

void draw() {


}

void mousePressed(){
    
   if(mouseX<src.width && mouseY<yt+src.height){
        for (Blob b : blobs) {            
              b.show();
              if(b.minx<mouseX && b.maxx>mouseX && b.miny<mouseY-yt && b.maxy>mouseY-yt){
               // b.highlight();
                src1=new PImage(b.maxx-b.minx+4,b.maxy-b.miny+4);
                for(int i=0;i<b.maxx-b.minx+4;i++){
                   for(int j=0;j<b.maxy-b.miny+4;j++){
                     src1.pixels[j*(b.maxx-b.minx+4)+i]=src.pixels[(j+b.miny-2)*src.width+i+b.minx-2];
                   }
                }
               
                
                //image(src1a, (src.width-src1.width)/2, yt+src.height+2);
                afisaj=true;
                curata();
              } 
         } 
     
   }
    
 
  
  
 
    PImage src1a=src1.copy();
    src1a.resize(0,src.height);
    int M=src1a.width;
    int N=src1a.height;    
     if(mouseX>2*src.width && mouseX<3*src.width && mouseY>yt+src.height && mouseY<yt+2*src.height){
        int x=mouseX-2*src.width-(src.width-src1a.width)/2;
        int y=mouseY-src.height-yt;
        float r=2*sqrt(M*M+N*N)*(x-(M-1)/2)/(M-1);
        float theta=PI*(y-(N-1)/2)/(N-1);
        strokeWeight(2);
        stroke(0, 0, 0);
        int intersectieY1=round(r/cos(theta));
        int intersectieX1=round(r/sin(theta));
        int intersectieX2=0;
        int intersectieY2=0;
        
        
        println("B:("+intersectieX2+","+intersectieY1+")-("+intersectieX1+","+intersectieY2+") - theta: "+theta);
        if(intersectieY1>N-1) {
          intersectieX2=round((intersectieY1-N+1)/tan(theta));
          intersectieY1=N-1;
        }
        if(intersectieX1>M-1) {
          intersectieY2=round((intersectieX1-M+1)*tan(theta));
          intersectieX1=M-1;
        }
        if(intersectieY1<0 && intersectieX1>0) {
          intersectieY1=intersectieY2+(intersectieY2-intersectieY1);
          intersectieX2=intersectieX1+(intersectieX1-intersectieX2);
        }
        if(intersectieX1<0 && intersectieY1>0) {
          intersectieX1=intersectieX2+(intersectieX2-intersectieX1);
          intersectieY2=intersectieY1+(intersectieY1-intersectieY2);
        }
        println("A:("+intersectieX2+","+intersectieY1+")-("+intersectieX1+","+intersectieY2+")");
        
        if(abs(theta)<0.000001) {
           intersectieY2=intersectieY1; 
        }
  
     /*   if(intersectieY1>N-1) {
          intersectieX2=round((intersectieY1-N+1)/tan(theta));
          intersectieY1=N-1;
        }
        if(intersectieX1>M-1) {
          intersectieY2=round((intersectieX1-M+1)*tan(theta));
          intersectieX1=M-1;
        }*/
        
        //if(intersectieX2<M && intersectieY2<N && intersectieX2>=0 && intersectieY2>=0 && intersectieX1>=0 && intersectieY1>=0) {
          stroke(0);
          line(intersectieX2+(src.width-src1a.width)/2,intersectieY1+src.height+yt,intersectieX1+(src.width-src1a.width)/2,intersectieY2+src.height+yt);
        //}
        //println("r : "+r);
        //println("theta : "+theta*180/PI);
        //println();
        stroke(255,0,0);
        strokeWeight(1);
        noFill();
        circle(mouseX,mouseY,5);
     }
    
  
}

void keyPressed(){
 if(key=='c') curata(); 
  
}

PImage FFT(PImage intrare, int luminozitate){
 intrare.filter(GRAY);
 PImage iesire=intrare.copy();
 int M=intrare.width;
 int N=intrare.height; 
 int maxim=0;
 int[] t=new int[M*N];
 float[] f=new float[M*N];
 for(int y=0;y<N;y++){
             for(int x=0;x<M;x++){
                f[y*M+x]=red(intrare.pixels[y*M+x]);
             }
 }
 return iesire;
}


PImage DFT2(PImage intrare, int luminozitate){
  intrare.filter(GRAY);
  PImage iesire=intrare.copy();
  int M=intrare.width;
  int N=intrare.height;
  int maxim=0;
  int[] t=new int[M*N]; 
  float[] f=new float[M*N];
  float[] Freal= new float[M*N];
  float[] Fimag= new float[M*N];
  int media=0;
   for(int y=0;y<N;y++){
             for(int x=0;x<M;x++){
                f[y*M+x]=red(intrare.pixels[y*M+x]);
             }
   }
   
   for(int v=0;v<N;v++){
     for(int x=0; x<M;x++){
       Freal[v*M+x]=0;
       Fimag[v*M+x]=0;
       for(int y=0;y<N;y++){
         Freal[v*M+x]+=f[y*M+x]*cos(2*PI*v*y/(N+0.0));
         Fimag[v*M+x]+=f[y*M+x]*sin(2*PI*v*y/(N+0.0));
       }
     }     
   }
   
  for(int v=0;v<N;v++){
      for(int u=0;u<M;u++){
        float real=0;
        float imag=0;
        for(int x=0;x<M;x++){            
             real+=Freal[v*M+x]*cos(2*PI*u*x/(M+0.0))-Fimag[v*M+x]*sin(2*PI*u*x/(M+0.0));
             imag+=Fimag[v*M+x]*cos(2*PI*u*x/(M+0.0))+Freal[v*M+x]*sin(2*PI*u*x/(M+0.0));
        }
        t[v*M+u]=round((sqrt((real*real+imag*imag)/(M*N*1.0))));

        if(t[v*M+u]>maxim) maxim=t[v*M+u];
        media+=t[v*M+u];
      }
    
   }
   media=media/(M*N);
   
  
   for(int v=0;v<N;v++){
      for(int u=0;u<M;u++){
        //t[v*M+u]=t[v*M+u]*255/maxim;
        t[v*M+u]=luminozitate*t[v*M+u]/media;
        if(t[v*M+u]>255) t[v*M+u]=255;        
        int vv=v+N/2;
        int uu=u+M/2;
        if(vv>N-1) vv=vv-N;
        if(uu>M-1) uu=uu-M;
        iesire.pixels[vv*M+uu]=color(t[v*M+u]);
      }
   }
   
  return iesire;
}

PImage DFT3(PImage intrare, int luminozitate){
  intrare.filter(GRAY);
  PImage iesire=intrare.copy();
  int M=intrare.width;
  int N=intrare.height;
  int maxim=0;
  int[] t=new int[M*N];
  int media=0;
  for(int v=0;v<N;v++){
      for(int u=0;u<M;u++){
        float real=0.0;
        float imag=0.0;
           for(int y=0;y<N;y++){
             for(int x=0;x<M;x++){
                float f=red(intrare.pixels[y*M+x]);
                real+=f*cos(2*PI*(u*x/(M+0.0)+v*y/(N+0.0)));
                imag+=f*sin(2*PI*(u*x/(M+0.0)+v*y/(N+0.0)));
             }
           }
        t[v*M+u]=round(sqrt((real*real+imag*imag)/(M*N*1.0)));
     
        if(t[v*M+u]>maxim) maxim=t[v*M+u];
        media+=t[v*M+u];
      }
     
   }
   media=media/(M*N);
   
  
   for(int v=0;v<N;v++){
      for(int u=0;u<M;u++){
        //t[v*M+u]/=maxim;
        t[v*M+u]=luminozitate*t[v*M+u]/media;
        if(t[v*M+u]>255) t[v*M+u]=255;        
        int vv=v+N/2;
        int uu=u+M/2;
        if(vv>N-1) vv=vv-N;
        if(uu>M-1) uu=uu-M;
        iesire.pixels[vv*M+uu]=color(t[v*M+u]);
      }
   }
   
  return iesire;
}



PImage Hough(PImage intrare){
  intrare.filter(GRAY);
  PImage iesire=intrare.copy();
  int M=intrare.width;
  int N=intrare.height;
  int[] t=new int[M*N];
  int maxim=0;
  for(int y=0;y<N;y++){
      for(int x=0;x<M;x++){
         t[y*M+x]=0;     
      }
  }
  for(int y=0;y<N;y++){
      for(int x=0;x<M;x++){
        if(red(intrare.pixels[y*M+x])>100) {
          for(float theta=-90;theta<=90;theta=theta+0.5){
            int r=round(x*sin(radians(theta))+y*cos(radians(theta)));
            int xx=round((M-1)/2+r*(M-1)/(2*sqrt(M*M+N*N)));
            int yy=round((N-1)/2+theta*(N-1)/180);
            
            t[yy*M+xx]++;   
            if(t[yy*M+xx]>maxim) maxim=t[yy*M+xx];
          }
        }
      }
  }
  
  for(int y=0;y<N;y++){
      for(int x=0;x<M;x++){
         iesire.pixels[y*M+x]=color(round(t[y*M+x]*255/maxim));   
      }
  }
  
  return iesire;
}
  
  
float distanta(float x1, float y1, float x2, float y2) {
  float d = sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
  return d;
}


float distanta(float x1, float y1, float z1, float x2, float y2, float z2) {
  float d = sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) +(z2-z1)*(z2-z1));
  return d;
}

double m(PImage intrare, int p, int q){
   double moment=0.0;
   intrare.filter(GRAY);
   int M=intrare.width;
   int N=intrare.height;
   for(int y=0;y<N;y++){
       double yy=1.0;
       for(int i=0;i<q;i++){
              yy=yy*y; 
       }
       
       for(int x=0;x<M;x++){
           double f=red(intrare.pixels[M*y+x])/255.0;
           double xx=1.0;           
           for(int i=0;i<p;i++){
              xx=xx*x; 
           }
          
          moment=moment+xx*yy*f;
       }
   }
   
   return moment;  
}
  
  
double miu(PImage intrare, int p, int q){
   double m00=m(intrare,0,0);
   double xc=m(intrare,1,0)/m00;
   double yc=m(intrare,0,1)/m00;
   
   println("xc: "+xc+" ; yc: "+yc);
   
   double moment=0.0;
   intrare.filter(GRAY);
   int M=intrare.width;
   int N=intrare.height;  
  
   double minim=0;
   double xmin=0, ymin=0;

   for(int y=0;y<N;y++){
       double yy=1.0;
       for(int i=0;i<q;i++){
              yy=yy*(y-yc); 
       }
       
       for(int x=0;x<M;x++){
           double f=red(intrare.pixels[M*y+x])/255.0;
           double xx=1.0;           
           for(int i=0;i<p;i++){
              xx=xx*(x-xc); 
           }
          
          moment=moment+xx*yy*f;
          if(moment<minim) { minim=moment; xmin=x; ymin=y;}
       }
   }

   println("M: "+M+" , N: "+N);
   println("minim: "+minim+" , x : "+xmin+" , y : "+ymin);
   return moment; 
  
}

float afisaj(double numar){
  float numar_=round(100*(float)numar)/100.0;
  return numar_; 
}
  
double mi1(PImage intrare){
  double m00=m(intrare,0,0);
  double moment=miu(intrare,0,2)+miu(intrare,2,0);
  //double moment=miu(intrare,0,1);
  
  return moment*100.0/m00/m00;
}

double mi2(PImage intrare){
  double m00=m(intrare,0,0);
  double moment1=miu(intrare,2,0)-miu(intrare,0,2);
  double moment2=miu(intrare,1,1);
  double moment_=moment1*moment1+4*moment2*moment2;
  double moment=sqrt((float)moment_);
  return moment*100.0/m00/m00;
}

double mi3(PImage intrare){
  double m00=m(intrare,0,0);
  double moment1=miu(intrare,3,0)-3*miu(intrare,1,2);
  double moment2=3*miu(intrare,2,1)-miu(intrare,0,3);
  double moment_=moment1*moment1+moment2*moment2;
  double moment=sqrt((float)moment_);
  return moment*100.0/m00/m00/sqrt((float)m00);
}

double mi4(PImage intrare){
  double m00=m(intrare,0,0);
  double moment1=miu(intrare,3,0)+miu(intrare,1,2);
  double moment2=miu(intrare,2,1)+miu(intrare,0,3);
  double moment_=moment1*moment1+moment2*moment2;
  double moment=sqrt((float)moment_);
  return moment*1000.0/m00/m00/sqrt((float)m00);
}

float stdev(float[] minv){
    float sum=0;
    float media;
    int N=minv.length;
    for(int i=0; i<N; i++){
      sum+=minv[i];      
    }
    media=sum/N;
    sum=0;
    for(int i=0; i<N; i++){
      sum+=(minv[i]-media)*(minv[i]-media);      
    }
    sum=sqrt(sum/(N-1));
    
    return sum;
}


float dist4(float inv1c, float inv2c, float inv3c, float inv4c, float inv1n, float inv2n, float inv3n, float inv4n, float stdev1, float stdev2, float stdev3, float stdev4){
  float distanta;
  distanta=(inv1c-inv1n)*(inv1c-inv1n)/stdev1/stdev1+(inv2c-inv2n)*(inv2c-inv2n)/stdev2/stdev2+(inv3c-inv3n)*(inv3c-inv3n)/stdev3/stdev3+(inv4c-inv4n)*(inv4c-inv4n)/stdev4/stdev4;
  distanta=sqrt(distanta);
  return distanta;
  
}
