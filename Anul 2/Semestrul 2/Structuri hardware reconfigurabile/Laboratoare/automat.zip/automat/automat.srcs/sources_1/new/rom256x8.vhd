----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2025 01:16:02 PM
-- Design Name: 
-- Module Name: rom256x8 - rom256x8_a
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rom256x8 is
    Port ( adrese : in STD_LOGIC_VECTOR (7 downto 0);
           cs : in STD_LOGIC;
           oe : in STD_LOGIC;
           clk : in std_logic;
           data : out STD_LOGIC_VECTOR (7 downto 0));
end rom256x8;

architecture rom256x8_a of rom256x8 is
signal sdata : std_logic_vector(7 downto 0);
begin
    with adrese select
    sdata <= 
    
    --aici introducem continutul memoriei in forma <data> WHEN <val. adresa>
    --"00000000" when "00000000", --format binar mult de scris
    X"10" when X"00",--format hexa putin de scris
    X"20" when X"01",
    X"65" when X"02",
    X"00" when X"03",
    X"E4" when X"04",
    X"00" when X"05",
    X"F6" when X"06",
    ----------
    
    X"00" when others;
    
    process(cs,oe,clk)
    begin
        if cs = '1' and oe = '1' then
            data <= sdata;
        else
            data <= "ZZZZZZZZ";
        end if;
    end process;
end rom256x8_a;
