onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib crom_opt

do {wave.do}

view wave
view structure
view signals

do {crom.udo}

run -all

quit -force
