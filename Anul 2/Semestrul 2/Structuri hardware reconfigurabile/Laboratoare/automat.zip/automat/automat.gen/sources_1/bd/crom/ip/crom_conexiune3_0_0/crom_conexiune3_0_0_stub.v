// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue Apr 29 16:18:34 2025
// Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/SHRCN2025/automat/automat.gen/sources_1/bd/crom/ip/crom_conexiune3_0_0/crom_conexiune3_0_0_stub.v
// Design      : crom_conexiune3_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s100fgga676-2
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "conexiune3,Vivado 2020.2" *)
module crom_conexiune3_0_0(vcc, gnd)
/* synthesis syn_black_box black_box_pad_pin="vcc,gnd" */;
  output vcc;
  output gnd;
endmodule
