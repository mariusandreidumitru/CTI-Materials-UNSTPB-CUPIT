--Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
--Date        : Tue Apr 29 18:24:05 2025
--Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
--Command     : generate_target crom_wrapper.bd
--Design      : crom_wrapper
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity crom_wrapper is
  port (
    F : out STD_LOGIC_VECTOR ( 3 downto 0 );
    T1 : in STD_LOGIC;
    T2 : in STD_LOGIC;
    adrese : out STD_LOGIC_VECTOR ( 7 downto 0 );
    clk : in STD_LOGIC;
    data : out STD_LOGIC_VECTOR ( 7 downto 0 );
    reset : in STD_LOGIC
  );
end crom_wrapper;

architecture STRUCTURE of crom_wrapper is
  component crom is
  port (
    clk : in STD_LOGIC;
    reset : in STD_LOGIC;
    T1 : in STD_LOGIC;
    T2 : in STD_LOGIC;
    F : out STD_LOGIC_VECTOR ( 3 downto 0 );
    adrese : out STD_LOGIC_VECTOR ( 7 downto 0 );
    data : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  end component crom;
begin
crom_i: component crom
     port map (
      F(3 downto 0) => F(3 downto 0),
      T1 => T1,
      T2 => T2,
      adrese(7 downto 0) => adrese(7 downto 0),
      clk => clk,
      data(7 downto 0) => data(7 downto 0),
      reset => reset
    );
end STRUCTURE;
