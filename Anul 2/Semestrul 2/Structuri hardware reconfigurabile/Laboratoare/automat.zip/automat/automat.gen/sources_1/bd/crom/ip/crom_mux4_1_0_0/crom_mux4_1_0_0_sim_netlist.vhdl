-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue Apr 29 16:18:34 2025
-- Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               d:/SHRCN2025/automat/automat.gen/sources_1/bd/crom/ip/crom_mux4_1_0_0/crom_mux4_1_0_0_sim_netlist.vhdl
-- Design      : crom_mux4_1_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7s100fgga676-2
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity crom_mux4_1_0_0_mux4_1 is
  port (
    y : out STD_LOGIC;
    i1 : in STD_LOGIC;
    i0 : in STD_LOGIC;
    i3 : in STD_LOGIC;
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    i2 : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of crom_mux4_1_0_0_mux4_1 : entity is "mux4_1";
end crom_mux4_1_0_0_mux4_1;

architecture STRUCTURE of crom_mux4_1_0_0_mux4_1 is
begin
\y__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0AAFFCCF0AA00CC"
    )
        port map (
      I0 => i1,
      I1 => i0,
      I2 => i3,
      I3 => s(1),
      I4 => s(0),
      I5 => i2,
      O => y
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity crom_mux4_1_0_0 is
  port (
    i0 : in STD_LOGIC;
    i1 : in STD_LOGIC;
    i2 : in STD_LOGIC;
    i3 : in STD_LOGIC;
    s : in STD_LOGIC_VECTOR ( 1 downto 0 );
    y : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of crom_mux4_1_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of crom_mux4_1_0_0 : entity is "crom_mux4_1_0_0,mux4_1,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of crom_mux4_1_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of crom_mux4_1_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of crom_mux4_1_0_0 : entity is "mux4_1,Vivado 2020.2";
end crom_mux4_1_0_0;

architecture STRUCTURE of crom_mux4_1_0_0 is
begin
U0: entity work.crom_mux4_1_0_0_mux4_1
     port map (
      i0 => i0,
      i1 => i1,
      i2 => i2,
      i3 => i3,
      s(1 downto 0) => s(1 downto 0),
      y => y
    );
end STRUCTURE;
