// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue Apr 29 16:18:34 2025
// Host        : DESKTOP-V480EDE running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               d:/SHRCN2025/automat/automat.gen/sources_1/bd/crom/ip/crom_numarator_0_0/crom_numarator_0_0_sim_netlist.v
// Design      : crom_numarator_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7s100fgga676-2
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "crom_numarator_0_0,numarator,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "numarator,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module crom_numarator_0_0
   (reset,
    clk,
    load,
    cin,
    q);
  (* x_interface_info = "xilinx.com:signal:reset:1.0 reset RST" *) (* x_interface_parameter = "XIL_INTERFACENAME reset, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input reset;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET reset, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.000, INSERT_VIP 0" *) input clk;
  input load;
  input [3:0]cin;
  output [3:0]q;

  wire [3:0]cin;
  wire clk;
  wire load;
  wire [3:0]q;
  wire reset;

  crom_numarator_0_0_numarator U0
       (.cin(cin),
        .clk(clk),
        .load(load),
        .q(q),
        .reset(reset));
endmodule

(* ORIG_REF_NAME = "numarator" *) 
module crom_numarator_0_0_numarator
   (q,
    clk,
    reset,
    load,
    cin);
  output [3:0]q;
  input clk;
  input reset;
  input load;
  input [3:0]cin;

  wire [3:0]cin;
  wire clk;
  wire load;
  wire [3:0]p_0_in;
  wire [3:0]q;
  wire reset;

  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h74)) 
    \vq[0]_i_1 
       (.I0(q[0]),
        .I1(load),
        .I2(cin[0]),
        .O(p_0_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h6F60)) 
    \vq[1]_i_1 
       (.I0(q[0]),
        .I1(q[1]),
        .I2(load),
        .I3(cin[1]),
        .O(p_0_in[1]));
  LUT5 #(
    .INIT(32'h78FF7800)) 
    \vq[2]_i_1 
       (.I0(q[0]),
        .I1(q[1]),
        .I2(q[2]),
        .I3(load),
        .I4(cin[2]),
        .O(p_0_in[2]));
  LUT6 #(
    .INIT(64'h7F80FFFF7F800000)) 
    \vq[3]_i_1 
       (.I0(q[1]),
        .I1(q[0]),
        .I2(q[2]),
        .I3(q[3]),
        .I4(load),
        .I5(cin[3]),
        .O(p_0_in[3]));
  FDCE \vq_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(p_0_in[0]),
        .Q(q[0]));
  FDCE \vq_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(p_0_in[1]),
        .Q(q[1]));
  FDCE \vq_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(p_0_in[2]),
        .Q(q[2]));
  FDCE \vq_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .CLR(reset),
        .D(p_0_in[3]),
        .Q(q[3]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
