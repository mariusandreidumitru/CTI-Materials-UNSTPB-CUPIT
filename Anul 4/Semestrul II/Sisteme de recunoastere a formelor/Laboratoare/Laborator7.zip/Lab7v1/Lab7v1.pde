import ch.bildspur.vision.*; 
import ch.bildspur.vision.result.*; 
import ch.bildspur.vision.network.*;

DeepVision vision;
YOLONetwork network;
ResultList<ObjectDetectionResult> detections;
PImage src;

void settings(){
 src=loadImage("imagine.jpg");
 size(src.width, src.height);  
}

void setup(){
 vision=new DeepVision(this);
 network=vision.createYOLOv4();
 network.setup();
 network.setConfidenceThreshold(0.2); 
}

void draw(){
 image(src,0,0);
 detections=network.run(src); 
 for(ObjectDetectionResult detection : detections){ 
    int x=detection.getX();
    int y=detection.getY();
    int w=detection.getWidth();
    int h=detection.getHeight();
    String nume=detection.getClassName();
    noFill();
    stroke(255,0,0);
    rect(x,y,w,h);
    text(nume,x,y);
 }
 noLoop(); 
}
