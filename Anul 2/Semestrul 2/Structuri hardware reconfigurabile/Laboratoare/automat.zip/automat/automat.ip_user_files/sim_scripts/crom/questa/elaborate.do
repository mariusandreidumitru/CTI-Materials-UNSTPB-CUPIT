vopt +acc=npr -l elaborate.log -L xil_defaultlib -L secureip -work xil_defaultlib xil_defaultlib.crom -o crom_opt
