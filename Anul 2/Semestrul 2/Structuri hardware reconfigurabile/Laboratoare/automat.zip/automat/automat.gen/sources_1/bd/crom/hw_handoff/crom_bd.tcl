
################################################################
# This is a generated script based on design: crom
#
# Though there are limitations about the generated script,
# the main purpose of this utility is to make learning
# IP Integrator Tcl commands easier.
################################################################

namespace eval _tcl {
proc get_script_folder {} {
   set script_path [file normalize [info script]]
   set script_folder [file dirname $script_path]
   return $script_folder
}
}
variable script_folder
set script_folder [_tcl::get_script_folder]

################################################################
# Check if script is running in correct Vivado version.
################################################################
set scripts_vivado_version 2020.2
set current_vivado_version [version -short]

if { [string first $scripts_vivado_version $current_vivado_version] == -1 } {
   puts ""
   catch {common::send_gid_msg -ssname BD::TCL -id 2041 -severity "ERROR" "This script was generated using Vivado <$scripts_vivado_version> and is being run in <$current_vivado_version> of Vivado. Please run the script in Vivado <$scripts_vivado_version> then open the design in Vivado <$current_vivado_version>. Upgrade the design by running \"Tools => Report => Report IP Status...\", then run write_bd_tcl to create an updated script."}

   return 1
}

################################################################
# START
################################################################

# To test this script, run the following commands from Vivado Tcl console:
# source crom_script.tcl


# The design that will be created by this Tcl script contains the following 
# module references:
# conexiune1, conexiune2, conexiune3, dmux1_4, mux4_1, numarator, rom256x8

# Please add the sources of those modules before sourcing this Tcl script.

# If there is no project opened, this script will create a
# project, but make sure you do not have an existing project
# <./myproj/project_1.xpr> in the current working folder.

set list_projs [get_projects -quiet]
if { $list_projs eq "" } {
   create_project project_1 myproj -part xc7s100fgga676-2
   set_property BOARD_PART xilinx.com:sp701:part0:1.0 [current_project]
}


# CHANGE DESIGN NAME HERE
variable design_name
set design_name crom

# If you do not already have an existing IP Integrator design open,
# you can create a design using the following command:
#    create_bd_design $design_name

# Creating design if needed
set errMsg ""
set nRet 0

set cur_design [current_bd_design -quiet]
set list_cells [get_bd_cells -quiet]

if { ${design_name} eq "" } {
   # USE CASES:
   #    1) Design_name not set

   set errMsg "Please set the variable <design_name> to a non-empty value."
   set nRet 1

} elseif { ${cur_design} ne "" && ${list_cells} eq "" } {
   # USE CASES:
   #    2): Current design opened AND is empty AND names same.
   #    3): Current design opened AND is empty AND names diff; design_name NOT in project.
   #    4): Current design opened AND is empty AND names diff; design_name exists in project.

   if { $cur_design ne $design_name } {
      common::send_gid_msg -ssname BD::TCL -id 2001 -severity "INFO" "Changing value of <design_name> from <$design_name> to <$cur_design> since current design is empty."
      set design_name [get_property NAME $cur_design]
   }
   common::send_gid_msg -ssname BD::TCL -id 2002 -severity "INFO" "Constructing design in IPI design <$cur_design>..."

} elseif { ${cur_design} ne "" && $list_cells ne "" && $cur_design eq $design_name } {
   # USE CASES:
   #    5) Current design opened AND has components AND same names.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 1
} elseif { [get_files -quiet ${design_name}.bd] ne "" } {
   # USE CASES: 
   #    6) Current opened design, has components, but diff names, design_name exists in project.
   #    7) No opened design, design_name exists in project.

   set errMsg "Design <$design_name> already exists in your project, please set the variable <design_name> to another value."
   set nRet 2

} else {
   # USE CASES:
   #    8) No opened design, design_name not in project.
   #    9) Current opened design, has components, but diff names, design_name not in project.

   common::send_gid_msg -ssname BD::TCL -id 2003 -severity "INFO" "Currently there is no design <$design_name> in project, so creating one..."

   create_bd_design $design_name

   common::send_gid_msg -ssname BD::TCL -id 2004 -severity "INFO" "Making design <$design_name> as current_bd_design."
   current_bd_design $design_name

}

common::send_gid_msg -ssname BD::TCL -id 2005 -severity "INFO" "Currently the variable <design_name> is equal to \"$design_name\"."

if { $nRet != 0 } {
   catch {common::send_gid_msg -ssname BD::TCL -id 2006 -severity "ERROR" $errMsg}
   return $nRet
}

##################################################################
# DESIGN PROCs
##################################################################



# Procedure to create entire design; Provide argument to make
# procedure reusable. If parentCell is "", will use root.
proc create_root_design { parentCell } {

  variable script_folder
  variable design_name

  if { $parentCell eq "" } {
     set parentCell [get_bd_cells /]
  }

  # Get object for parentCell
  set parentObj [get_bd_cells $parentCell]
  if { $parentObj == "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2090 -severity "ERROR" "Unable to find parent cell <$parentCell>!"}
     return
  }

  # Make sure parentObj is hier blk
  set parentType [get_property TYPE $parentObj]
  if { $parentType ne "hier" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2091 -severity "ERROR" "Parent <$parentObj> has TYPE = <$parentType>. Expected to be <hier>."}
     return
  }

  # Save current instance; Restore later
  set oldCurInst [current_bd_instance .]

  # Set parent object as current
  current_bd_instance $parentObj


  # Create interface ports

  # Create ports
  set F [ create_bd_port -dir O -from 3 -to 0 F ]
  set T1 [ create_bd_port -dir I T1 ]
  set T2 [ create_bd_port -dir I T2 ]
  set adrese [ create_bd_port -dir O -from 7 -to 0 adrese ]
  set clk [ create_bd_port -dir I clk ]
  set data [ create_bd_port -dir O -from 7 -to 0 data ]
  set reset [ create_bd_port -dir I reset ]

  # Create instance: conexiune1_0, and set properties
  set block_name conexiune1
  set block_cell_name conexiune1_0
  if { [catch {set conexiune1_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $conexiune1_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: conexiune2_0, and set properties
  set block_name conexiune2
  set block_cell_name conexiune2_0
  if { [catch {set conexiune2_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $conexiune2_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: conexiune3_0, and set properties
  set block_name conexiune3
  set block_cell_name conexiune3_0
  if { [catch {set conexiune3_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $conexiune3_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: dmux1_4_0, and set properties
  set block_name dmux1_4
  set block_cell_name dmux1_4_0
  if { [catch {set dmux1_4_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $dmux1_4_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: mux4_1_0, and set properties
  set block_name mux4_1
  set block_cell_name mux4_1_0
  if { [catch {set mux4_1_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $mux4_1_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: numarator_0, and set properties
  set block_name numarator
  set block_cell_name numarator_0
  if { [catch {set numarator_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $numarator_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: rom256x8_0, and set properties
  set block_name rom256x8
  set block_cell_name rom256x8_0
  if { [catch {set rom256x8_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $rom256x8_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create port connections
  connect_bd_net -net T1_1 [get_bd_ports T1] [get_bd_pins mux4_1_0/i1]
  connect_bd_net -net T2_1 [get_bd_ports T2] [get_bd_pins mux4_1_0/i2]
  connect_bd_net -net clk_1 [get_bd_ports clk] [get_bd_pins numarator_0/clk] [get_bd_pins rom256x8_0/clk]
  connect_bd_net -net conexiune1_0_cin [get_bd_pins conexiune1_0/cin] [get_bd_pins numarator_0/cin]
  connect_bd_net -net conexiune1_0_selDmux [get_bd_pins conexiune1_0/selDmux] [get_bd_pins dmux1_4_0/s]
  connect_bd_net -net conexiune1_0_selMux [get_bd_pins conexiune1_0/selMux] [get_bd_pins mux4_1_0/s]
  connect_bd_net -net conexiune2_0_adrese [get_bd_ports adrese] [get_bd_pins conexiune2_0/adrese] [get_bd_pins rom256x8_0/adrese]
  set_property HDL_ATTRIBUTE.DEBUG {true} [get_bd_nets conexiune2_0_adrese]
  connect_bd_net -net conexiune2_0_cs [get_bd_pins conexiune2_0/cs] [get_bd_pins rom256x8_0/cs]
  connect_bd_net -net conexiune2_0_oe [get_bd_pins conexiune2_0/oe] [get_bd_pins rom256x8_0/oe]
  connect_bd_net -net conexiune3_0_gnd [get_bd_pins conexiune3_0/gnd] [get_bd_pins mux4_1_0/i3]
  connect_bd_net -net conexiune3_0_vcc [get_bd_pins conexiune3_0/vcc] [get_bd_pins dmux1_4_0/e] [get_bd_pins mux4_1_0/i0]
  connect_bd_net -net dmux1_4_0_y [get_bd_ports F] [get_bd_pins dmux1_4_0/y]
  connect_bd_net -net mux4_1_0_y [get_bd_pins mux4_1_0/y] [get_bd_pins numarator_0/load]
  connect_bd_net -net numarator_0_q [get_bd_pins conexiune2_0/q] [get_bd_pins numarator_0/q]
  connect_bd_net -net reset_1 [get_bd_ports reset] [get_bd_pins numarator_0/reset]
  connect_bd_net -net rom256x8_0_data [get_bd_ports data] [get_bd_pins conexiune1_0/data] [get_bd_pins rom256x8_0/data]

  # Create address segments


  # Restore current instance
  current_bd_instance $oldCurInst

  validate_bd_design
  save_bd_design
}
# End of create_root_design()


##################################################################
# MAIN FLOW
##################################################################

create_root_design ""


